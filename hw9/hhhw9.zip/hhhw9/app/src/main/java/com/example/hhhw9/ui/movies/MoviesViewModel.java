package com.example.hhhw9.ui.movies;

import androidx.lifecycle.ViewModel;

public class MoviesViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}