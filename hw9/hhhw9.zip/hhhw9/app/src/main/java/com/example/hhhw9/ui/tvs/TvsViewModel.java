package com.example.hhhw9.ui.tvs;

import androidx.lifecycle.ViewModel;

public class TvsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}